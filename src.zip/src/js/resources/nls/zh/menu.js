define({

      "database": "数据库",
      "project": "项目",
      "loggedInAs": "当前用户",
      "tools": "工具箱",
      "help": "帮助",
      "logout": "登出",
      "open": "打开",
      "importData":"导入数据",
      "exportProject":"导出项目",
      "systems":"系统",
      "repositories":"分支",
      "options":"个性化",
      "contents":"帮助信息",
      "about":"关于系统",
      "testPlan":"测试计划",
      "requirements":"测试需求",
      "tests":"测试脚本",
      "testExecution":"执行结果",
      "issues":"紧急问题",
      "reports":"结果报告",
      "dashboard":"报表分析"
});