define({
  "root": {
      "database": "Database",
      "project": "Project",
      "loggedInAs": "Logged in as",
      "tools": "Tools",
      "help": "Help",
      "logout": "Logout",
      "open": "Open",
      "importData":"Import Data...",
      "exportProject":"Export Project"
  },
  "zh": true,
  "cs": true
});