/**
 * Copyright (c) 2014, 2017, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 */
'use strict';

/**
 * Example of Require.js boostrap javascript
 */

requirejs.config(
{
  baseUrl: 'js',

  // Path mappings for the logical module names
  paths:
  //injector:mainReleasePaths
  {
    'knockout': 'libs/knockout/knockout-3.4.0.debug',
    'jquery': 'libs/jquery/jquery-3.1.0',
    'jqueryui-amd': 'libs/jquery/jqueryui-amd-1.12.0',
    "jquery.cookie": 'libs/jquery/jquery-cookie-1.4.1/jquery.cookie',
    'i18next': 'libs/i18next/i18next.min',
    'promise': 'libs/es6-promise/es6-promise',
    'hammerjs': 'libs/hammer/hammer-2.0.8',
    'ojdnd': 'libs/dnd-polyfill/dnd-polyfill-1.0.0',
    'ojs': 'libs/oj/v2.3.0/debug',
    'ojL10n': 'libs/oj/v2.3.0/ojL10n',
    'ojtranslations': 'libs/oj/v2.3.0/resources',
    'text': 'libs/require/text',
    'signals': 'libs/js-signals/signals',
    'customElements': 'libs/webcomponents/CustomElements',
    'proj4': 'libs/proj4js/dist/proj4-src',
    'myRequest':'libs/myRequest',
    'css': 'libs/require-css/css'
  }
  //endinjector
  ,
  // Shim configurations for modules that do not expose AMD
  shim:
  {
    'jquery':
    {
      exports: ['jQuery', '$']
    },
    "jquery.cookie"  : ["jquery"] 
  }
}
);

/**
 * A top-level require call executed by the Application.
 * Although 'ojcore' and 'knockout' would be loaded in any case (they are specified as dependencies
 * by the modules themselves), we are listing them explicitly to get the references to the 'oj' and 'ko'
 * objects in the callback
 */
 require(['ojs/ojcore', 'knockout', 'jquery','myRequest', 'jquery.cookie',
                     'ojs/ojknockout', 'ojs/ojinputtext','ojs/ojselectcombobox','ojs/ojbutton'],
            function(oj, ko, $, rqt)
            {
              function LoginModel() {
                var self = this;
                self.database = ko.observable("OLT");
                self.username = ko.observable("");
                self.password = ko.observable("");
                self.warnMsg = ko.observable("");
                self.login = function(){
                  self.warnMsg("Try to login!");
                  var beforeSend =  function (xhr) {
                    /* Authorization header */
                    xhr.setRequestHeader("Authorization", "Basic b3RtLWpldDpvdG0tamV0");
                  };
                  var success = function (msg) {//On Successfull service call   
                          if(!!msg.access_token){
                            $.cookie("user",JSON.stringify(msg),{ path: "/"});
                            window.location.href = "../";
                          }else{
                            self.warnMsg("Unvalid username or password!");
                          }
                  };
                  var error = function (xhr) { 
                        self.warnMsg(xhr.responseText||"Login failed"+"; please try again later!"); 
                  };
                  rqt.post("oauth/token?grant_type=password",{username:self.username(),password:self.password()},"application/x-www-form-urlencoded",beforeSend,success,error,false);
                }
              }
              
              $(
                  function()
                  {
                    ko.applyBindings(new LoginModel(), document.getElementById('form-container'));
                  }
              );
            }
        );
