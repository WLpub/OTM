/**
 * Copyright (c) 2014, 2017, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 */
/*
 * Your about ViewModel code goes here
 */
define(['ojs/ojcore', 'knockout', 'jquery','myRequest','ojs/ojinputtext','ojs/ojdatetimepicker','ojs/ojTree','ojs/ojradioset','ojs/ojjsontreedatasource','ojs/ojknockout', 'ojs/ojcheckboxset', 'ojs/ojbutton', 'ojs/ojtoolbar', 'ojs/ojmenu','ojs/ojdialog','ojs/ojselectcombobox'],
 function(oj, ko, $, rqt) {
    function TestPlanViewModel() {
      var self = this;
      self.handleActivated = function(info) {
        self.projectId = 1;
      };
      self.handleAttached = function(info) {
      };
      self.handleBindingsApplied = function(info) {       
      };

      self.handleDetached = function(info) {
        // Implement if needed
      };
      self.translate = function(key){
        return oj.Translations.getTranslatedString(key);
      };
       //selected node
      self.selectedNode = ko.observable(-1);
      self.editState = false;
      self.tempNode=
      {
          "assignees": ko.observableArray([
            {
              "id": -1,
              "state": "...",
              "url": "...",
              "username": "...",
            }
          ]),
          "closed_at": ko.observable("..."),
          "commentsCount": ko.observable(0),
          "created_at": ko.observable("..."),
          "creator": {
            "id": ko.observable(-1),
            "state": ko.observable("..."),
            "url": ko.observable("..."),
            "username": ko.observable("...")
          },
          "due_date": ko.observable("..."),
          "issue_activities": ko.observableArray([
            {
              "activity_user": {
                "id": -1,
                "state": "...",
                "url":"...",
                "username":"..."
              },
              "component": "...",
              "description": "...",
              "name": "...",
              "platform": "...",
              "priority": "...",
              "severity": "...",
              "solution": "...",
              "status": "...",
              "updated_at": "...",
              "version": "..."
            }
          ]),
          "issue_id": ko.observable(-1),
          "issue_iid": ko.observable(-1),
          "labels":  ko.observableArray([
            {
              "color": "...",
              "created_at": "...",
              "id": -1,
              "name": "...",
              "updated_at": "...",
              "url": "..."
            }
          ]),
          "project_id": ko.observable(-1),
          "url": ko.observable("...")
      };
      self.editNode=
      {
        "assignee_ids": ko.observable(-1),
        "author_id": 1,
        "component": ko.observable(""),
        "description": ko.observable(""),
        "due_date": ko.observable(""),
        "name": ko.observable(""),
        "platform": ko.observable(""),
        "priority": ko.observable(""),
        "severity": ko.observable(""),
        "solution": ko.observable(""),
        "status": ko.observable(""),
        "version": ko.observable(""),
      };

      self.treeJson = [];
      self.getJson = function  getJson(node, fn)       // get data json
      {
        var id = node.attr?node.attr("id"):-1;
        if(id<0){
          var success = function (issues) {
                      var data = [];
                      for(var i=0;i<issues.length;i++){
                        data.push({'title':issues[i].issue_activities[0].name,'attr':{'id':issues[i].issue_iid}});
                      }
                      fn(data);
                      self.treeJson  = data;
                      if(data.length>0){
                        self.selectedNode(data[0].attr.id);
                        $("#tree").ojTree("select", "#"+self.selectedNode());
                        updateView(issues[0]);
                      }
                     
                    };
          var error = function (xhr) { console.log(xhr.statusText); }; 
          rqt.get("api/projects/"+self.projectId+"/issues",null,null,null,success,error,true);
        }else{
          //do sth with id
        }
      };

      self.toolbarClassNames = ko.observableArray([]);

      self.toolbarClasses = ko.computed(function() {
            return self.toolbarClassNames().join(" ");
      }, self);


      self.openAddDialog = function(){
        self.editState = false;
        updateEdit();
        $("#addDialog").ojDialog("open");
      }
      self.openEditDialog = function(){
        self.editState = true;
        updateEdit();
        $("#addDialog").ojDialog("open");
      }

      self.addNode = function(){ 
        if(self.editState&&!!!self.selectedNode){
          alert("Please choose a node first!");
          return;
        }
        var data = getEditData();
        var success  =function(ret){
          $("#addDialog").ojDialog("close");
          if(!self.editState){
            $("#tree").ojTree("create", "#"+self.selectedNode(), "after", 
                              {"title" : ret.issue_activities[0].name, "attr" : {"id" : ret.issue_iid}});
          }else{
            $("#tree").ojTree('rename',"#"+self.selectedNode(), ret.issue_activities[0].name);
          }
          updateView(ret);
        };
        var error = function(){
          alert((self.editState?"Edit":"Create") +" node failed, please try again later!");
        }
        if(self.editState)
          rqt.put("api/projects/"+self.projectId+"/issues/"+self.selectedNode(),data,null,null,success,error,true);
        else
          rqt.post("api/projects/"+self.projectId+"/issues/",data,null,null,success,error,true);
      };
      self.resetNode = function(){
        updateEdit();
      };
      self.cancelNode = function(){
        $("#addDialog").ojDialog("close");
      };
      self.deleteNode = function(){
        if(self.selectedNode<0){
          alert("Please choose a node first!");
          return;
        }
        var success  =function(){
          $("#tree").ojTree("remove", "#"+self.selectedNode());
         };
        var error = function(){
          alert("Delete node failed, please try again later!");
         }
        rqt.delete("api/projects/"+self.projectId+"/issues/"+self.selectedNode(),null,null,null,success,error,true);
      };
     
      

      self.moveUp = function(){
        var sibling = $("#tree").ojTree("getPrevSibling", "#"+self.selectedNode());
        if(sibling&&sibling.length>0){
          $("#tree").ojTree("move", "#"+self.selectedNode(),  sibling[0],"before",false);
        }
      }
      self.moveDown = function(){
        var sibling = $("#tree").ojTree("getNextSibling", "#"+self.selectedNode());
        if(sibling&&sibling.length>0){
          $("#tree").ojTree("move", "#"+self.selectedNode(),  sibling[0],"after",false);
        }
      }
      self.moveInto = function(){
        var sibling = $("#tree").ojTree("getPrevSibling", "#"+self.selectedNode());
        if(sibling&&sibling.length>0){
          $("#tree").ojTree("move", "#"+self.selectedNode(),  sibling[0],"last",false);
          $("#tree").ojTree("expand", sibling[0],true);
        }
      }
      self.moveOut = function(){
        var parent = $("#tree").ojTree("getParent", "#"+self.selectedNode());
        if(parent&&parent.length>0){
          $("#tree").ojTree("move", "#"+self.selectedNode(),  parent[0],"after",false);
        }
      }
      

      var updateView = function(issue){
        var success = function (issues) {
          self.tempNode.assignees(issues.assignees);
          self.tempNode.closed_at(issues.closed_at);
          self.tempNode.commentsCount(issues.commentsCount);
          self.tempNode.created_at(issues.created_at);
          self.tempNode.due_date(issues.due_date);
          self.tempNode.issue_activities(issues.issue_activities);
          self.tempNode.issue_id(issues.issue_id);
          self.tempNode.issue_iid(issues.issue_iid);
          self.tempNode.labels(issues.labels);
          self.tempNode.project_id(issues.project_id);
          self.tempNode.url(issues.url);
          self.tempNode.creator.id(issues.creator.id);
          self.tempNode.creator.state(issues.creator.state);
          self.tempNode.creator.url(issues.creator.url);
          self.tempNode.creator.username(issues.creator.username);
        };
        if(issue){
          success(issue);
        }else{
          var error = function (xhr) { console.log(xhr.statusText); };  
          rqt.get("api/projects/1/issues/"+self.selectedNode(),null,null,null,success,error,true);
        }
      };

      var getEditData = function(){
        var retData = {
          "assignee_ids": [self.editNode.assignee_ids()],
          "author_id": self.editNode.author_id,
          "component": self.editNode.component(),
          "description": self.editNode.description(),
          "due_date": self.editNode.due_date(),
          "name": self.editNode.name(),
          "platform":self.editNode.platform(),
          "priority": self.editNode.priority(),
          "severity": self.editNode.severity(),
          "solution": self.editNode.solution(),
          "status": self.editNode.status(),
          "version": self.editNode.version()
        };
        if(self.editState){ 
          if(self.editNode.assignee_ids()==-1){ retData.assignee_ids=[];}
          retData.assignee_ids =  retData.assignee_ids.concat(self.tempNode.assignees().map(function(temp){return temp.id;}));
        }
        return retData;
      };
     
      var updateEdit = function(){
        if(self.editState){
          self.editNode.assignee_ids(self.tempNode.assignees().length>0?self.tempNode.assignees()[0].id:-1);
          self.editNode.component(self.tempNode.issue_activities()[0].component);
          self.editNode.description(self.tempNode.issue_activities()[0].description);
          self.editNode.due_date(self.tempNode.issue_activities()[0].due_date);
          self.editNode.name(self.tempNode.issue_activities()[0].name);
          self.editNode.platform(self.tempNode.issue_activities()[0].platform);
          self.editNode.priority(self.tempNode.issue_activities()[0].priority);
          self.editNode.severity(self.tempNode.issue_activities()[0].severity);
          self.editNode.solution(self.tempNode.issue_activities()[0].solution);
          self.editNode.status(self.tempNode.issue_activities()[0].status);
          self.editNode.version(self.tempNode.issue_activities()[0].version);
        }else{
          self.editNode.assignee_ids(-1);
          self.editNode.component("");
          self.editNode.description("");
          self.editNode.due_date("");
          self.editNode.name("");
          self.editNode.platform("");
          self.editNode.priority("");
          self.editNode.severity("");
          self.editNode.solution("");
          self.editNode.status("");
          self.editNode.version("");
        }
      };
      $(document).ready(
        function()
        {
          $("#tree").on("ojoptionchange", function(e, ui) {
                 if (ui.option == "selection") {
                   // show selected nodes
                  var selected = _arrayToStr(ui.value) ;
                  self.selectedNode(selected);
                  updateView();
                }
          });
          $("#menuId").on('click', function() {
            console.log(self.selectedNode(),$("#menuId").val());
          });
        }
      );
    }
   
    // Convert a jQuery list of html element nodes to string containing node id's.
    function _arrayToStr(arr)
    {
       var s = "" ;
       $.each(arr, function(i, val)
          {
            if (i) {
              s += ", " ;
            }
            s += $(arr[i]).attr("id") ;
          }) ;

       return s ;
    };
    return new TestPlanViewModel();
  }
);
